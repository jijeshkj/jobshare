<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class ResumeController extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('pagination');
        $this->load->model('ResumeModel', 'resumeModel');
        $this->load->database();
        $this->load->model('AdminJobModel', 'model');
    }

    public function saveProfile() {

        $user = $this->session->userdata('username');
        $existRecord = $this->resumeModel->existRecord($user);
        $action = $this->input->post('submit');
        if ($action == 'profile') {
            $profile = array('Firstname' => $this->input->post('firstname'),
                'Lastname' => $this->input->post('lastname'),
                'Address' => $this->input->post('address'),
                'Whatsappnumber' => $this->input->post('whatsappnumber'),
                'FacebookId' => $this->input->post('facebookid'),
                'PinCode' => $this->input->post('pincode'),
                'PhoneNumber' => $this->input->post('phonenumber'));
            if ($existRecord) {
                if ($existRecord[0]->completed_status != 30) {
                    
                }
                $this->resumeModel->updateProfile($profile, $existRecord[0]->id);
            } else {
                $profile['userID'] = $user;
                $profile['completed_status'] = 30;
                $this->resumeModel->saveProfile($profile);
            }
        } else if ($action == 'experience') {
            $jobarray = serialize($this->input->post('jobtitle'));
            $experiencearray = serialize($this->input->post('experience'));
            $profile = array('JobTitle' => $jobarray, 'Experience' => $experiencearray);
            if ($existRecord) {
                $this->resumeModel->updateProfile($profile, $existRecord[0]->id);
            } else {
                $profile['userID'] = $user;
                $profile['completed_status'] = 20;
                $this->resumeModel->saveProfile($profile);
            }
        } else if ($action == 'education') {
            $educationarray = serialize($this->input->post('education'));
            $profile = array('Education_Details' => $educationarray);
            if ($existRecord) {
                $this->resumeModel->updateProfile($profile, $existRecord[0]->id);
            } else {
                $profile['userID'] = $user;
                $profile['completed_status'] = 35;
                $this->resumeModel->saveProfile($profile);
            }
        } else if ($action == 'additional') {
            $additional = ($this->input->post('description'));

            $profile = array('Additional_Informations' => $additional);
            if ($existRecord) {
                $this->resumeModel->updateProfile($profile, $existRecord[0]->id);
            } else {
                $profile['userID'] = $user;
                $profile['completed_status'] = 15;
                $this->resumeModel->saveProfile($profile);
            }
        }
    }

    public function getResume() {
        $data['records'] = $this->resumeModel->getCreatedResumes();
        $jobtitle = unserialize($data['records'][0]->JobTitle);
        $experience = unserialize($data['records'][0]->Experience);
        $education = unserialize($data['records'][0]->Education_Details);
        $data['records'][0]->JobTitle = $jobtitle;
        $data['records'][0]->Experience = $experience;
        $data['records'][0]->Education_Details = $education;

        $this->load->view('jobshare/resumePreview', $data);
    }

    public function searchResume() {
        $cat = $_POST['name'];


        /* pagination link */
        $config = array();
        $config["base_url"] = base_url() . "ResumeController/searchResume";
        $total_row = $this->resumeModel->record_count($cat);
        $config["total_rows"] = $total_row;
        $config["per_page"] = 4;
        $config['use_page_numbers'] = TRUE;
        $config['num_links'] = $total_row;
        $config['cur_tag_open'] = '&nbsp;<a class="current">';
        $config['cur_tag_close'] = '</a>';
        $config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';

        $this->pagination->initialize($config);
        if ($this->uri->segment(3)) {
            $page = ($this->uri->segment(3));
        } else {
            $page = 1;
        }

        $data = $this->resumeModel->searchResumes($config["per_page"], $cat);
        $str_links = $this->pagination->create_links();
        $links = explode('&nbsp;', $str_links);

        $categories = $this->model->getCategory();
        $locations = $this->model->viewLocation();
        $qalifications = $this->model->viewQualification();
        $jobtitle = $this->model->jobtitles();
        $this->load->view('jobshare/searchResumeResult', array('value' => $data, 'cat' => $categories,
            'locations' => $locations, 'qualification' => $qalifications, 'job_titles' => $jobtitle, 'links' => $links));
    }

}
