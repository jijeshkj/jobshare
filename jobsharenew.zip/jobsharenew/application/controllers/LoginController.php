<?php

class LoginController extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('LoginModel', 'logmodel');
        $this->load->model('JobShareModel', 'jobmodel');
        $this->load->database();
        $this->load->library('session');
    }

    public function login() {
        $usrname = $this->input->post("username");
        $password = $this->input->post('password');
        $role = $this->input->post('role');
        $result = $this->logmodel->login($usrname, $password, $role);
        if ($result) {
            if ($role == 'admin') {
                $data = "admin";
            } else {

                $status = $result[0]->status;
                if ($status == 1) {
                    $data = "user";
                } else {
                    $data = "Please Activate Your Account";
                }
            }
        } else {
            $data = "invalid user";
        }
        echo json_encode($data);
    }

    public function logout() {
        try {
            // $class = new LoginController();
            $this->session->unset_userdata('username');
            //$this->$class->postJob();
            redirect("welcome/index");
        } catch (Exception $ex) {
            
        }
    }

    function forgotPassword() {
        try {
            $this->load->view('jobshare/header');
            $this->load->view('jobshare/forgotpassword');
        } catch (Exception $ex) {
            
        }
    }

    function resetPassword() {
        $value = $this->input->post('username');
        $this->load->view('jobshare/header');
        $this->load->view('jobshare/resetpassword',array('email'=>$value));
    }

}
