<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class JobShareController extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('JobShareModel', 'jobmodel');
        $this->load->model('AdminJobModel', 'model');
        $this->load->model('ResumeModel', 'resumeModel');
        $this->load->database();
    }

    public function login() {
        $passvalue1 = $this->uri->segment(3);
        if ($passvalue1) {
            $passvalue['value'] = $passvalue1;
        } else {
            $passvalue['value'] = '';
        }

        $this->load->view('jobshare/header');
        $this->load->view('jobshare/login', $passvalue);
    }

    public function register() {
        $this->load->view('jobshare/header');
        $this->load->view('jobshare/register');
    }

    public function JobaddedProcess() {

        $data = array('company_name' => $this->input->post('companyname'), 'email' => $this->input->post('email'),
            'joblloc_id' => $this->input->post('location'), 'job_title' => $this->input->post('jobtitle'),
            'salary' => $this->input->post('salary'), 'description' => $this->input->post('description'),
            'quals_id' => $this->input->post('qualification'), 'experience' => $this->input->post('experience').$this->input->post('experienceType'), 'cat_id' => $this->input->post('category'));
        if ($data) {
            $this->model->saveJob($data);
            $this->session->set_flashdata("message", "Job Added successfully.");
            redirect('Jobsharecontroller/success', 'refresh');
        }
    }

    public function registerProcess() {
        $data = array('username' => $this->input->post('email'), 'password' => md5($this->input->post('password')), 'role' => 'user', 'hash' => md5(rand(0, 1000)));
        if ($data) {
            $insert = $this->jobmodel->register($data);
            if ($insert)
            // redirect('Jobsharecontroller/login', 'refresh');
                $config = Array(
                    'protocol' => 'smtp',
                    'smtp_host' => 'ssl://smtp.gmail.com',
                    'smtp_port' => 465,
                    'smtp_user' => 'jijeshs333@gmail.com', // change it to yours
                    'smtp_pass' => 'jijeshkj92@6882', // change it to yours
                    'mailtype' => 'html',
                    'charset' => 'iso-8859-1',
                    'wordwrap' => TRUE
                );
            $mydata = array('message' => 'I am a message that will be passed to a view');
            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");
            $from_email = "jijeshs333@gmail.com";
            $to_email = 'jiju7s4u@gmail.com';
            $this->email->from($from_email, 'Mind Harvest');
            $this->email->to($to_email);
            $this->email->subject('Account Varification');
            $this->email->set_mailtype('html');
            // $message = $this->load->view('jobshare/EmailTemplate',true);
            $message = '<h2 style="color:skyblue">Welcome TO Mind Harvest</h2><br>Thanks for signing up, !<br>
        Your account has been created. 
        Here are your login details.<br>
        -------------------------------------------------<br>
        Email   : ' . $data['username'] . '<br>
        password: ' . $this->input->post('password') . '<br>
        -------------------------------------------------<br>
       <h3> Please click this link to activate your account</h3>:<br>
        ' . base_url() . 'accountvarification?' .
                    'email=' . $data['username'] . '&hash=' . $data['hash'];
            $this->email->message($message);
            //Send mail 
            if ($this->email->send()) {

                $this->session->set_flashdata("email_sent", "Email sent successfully.");
                $this->session->set_flashdata("activationmsg", "Your Account is now Active");
                redirect('Jobsharecontroller/login', 'refresh');
            } else {

                $this->session->set_flashdata("email_sent", "Error in sending Email.");
                //   $this->load->view('email_form');
                echo show_error($this->email->print_debugger());
            }
        }
    }

    public function postJob() {
        $data['category'] = $this->model->getCategory();
        $data['locations'] = $this->model->viewLocation();
        $data['countries'] = $this->model->getCountry();
        $data['qualifications'] = $this->model->viewQualification();
        $this->load->view('jobshare/header');
        $this->load->view('jobshare/postjob', $data);
    }

    public function postResume() {
        try {
            $this->load->view('jobshare/header');
            $this->load->view('jobshare/postresume');
        } catch (Exception $ex) {
            
        }
    }

    public function uploadResume() {
        try {
            $this->load->view('jobshare/header');
            $this->load->view('jobshare/uploadresume');
        } catch (Exception $ex) {
            
        }
    }

    public function Resume() {
        try {
            $this->load->view('jobshare/header');
            $this->load->view('jobshare/Resume');
        } catch (Exception $ex) {
            
        }
    }

    public function SaveuploadResume() {
        if ($_FILES['file']['name']) {
            $name = $_FILES['file']['name'];
            $tempname = $_FILES['file']['tmp_name'];
            $namesplit = explode(".", $name);
            $randomnumber = rand();
            $image = 'resume' . $randomnumber . "." . end($namesplit);
            move_uploaded_file($tempname, $_SERVER['DOCUMENT_ROOT'] . "/jobsharenew/uploads/Resumes" . $image);
            $user = $this->session->userdata('username');
            $existRecord = $this->resumeModel->existRecord($user);



            $uploadarray = array('Firstname' => $this->input->post('firstname'),
                'JobTitle' => $this->input->post('jobtitle'),
                'Whatsappnumber' => $this->input->post('whatsappnumber'),
                'FacebookId' => $this->input->post('facebookid'),
                'Experience' => $this->input->post('experience'),
                'userID' => $this->session->userdata('username'),
                'file_name' => $image);
            if ($existRecord) {
                $result = $this->resumeModel->updateProfile($uploadarray, $existRecord[0]->id);
            } else {
                $profile['userID'] = $user;
                $result = $this->resumeModel->saveProfile($uploadarray);
            }
            if ($result) {
                $this->session->set_flashdata('message', 'Resume Upload Succesfully');
                redirect('Jobsharecontroller/success', 'refresh');
            }
        }
    }

    public function success() {
        // $this->load->view('jobshare/header');
        $this->load->view('jobshare/successPage');
    }

    public function resumeSearch() {
        try {
            $this->load->view('jobshare/header');
            $data = $this->resumeModel->getResumes();
            if ($data) {
                foreach ($data as $value) {
                    $pass[] = array('id' => $value->id, 'name' => $value->JobTitle);
                }
            }
            $uploadedvalues = $this->resumeModel->getUploadedResumes();
            if ($uploadedvalues) {
                foreach ($uploadedvalues as $records) {
                    $title = unserialize($records->JobTitle);
                    $uploadvalues[] = array('id' => $records->id, 'name' => $title);
                    array_merge($uploadvalues, $title);
                }
            }
            $this->load->view('jobshare/resumeSearch', array('value' => $pass, 'uploadedvalues' => $uploadvalues));
        } catch (Exception $ex) {
            
        }
    }

    public function checkExist() {
        $user = $this->input->post('user');
        $record = $this->jobmodel->getExistRecord($user);
        if ($record) {
            $record = TRUE;
        } else {
            $record = FALSE;
        }
        echo json_decode($record);
    }

    public function varificationProcess() {
        $record = $this->jobmodel->getHashKey($_GET['email']);
        if ($record) {
            if ($_GET['hash'] == $record[0]->hash) {
                $result = $this->jobmodel->UpdateUserstatus($_GET['email']);
                if ($result) {
                    $this->load->view('jobshare/varification_success');
                }
            }
        }
    }
    
    
    
      public function jobDetails() {
        $jobID = $this->uri->segment(3);
        $record = $this->jobmodel->jobRecords($jobID);
      
        if($record){
            $this->load->view('jobshare/header');
            $this->load->view('jobshare/JobDetails',array('values'=>$record));
           
        }
       
    }

    
    
    
    
    
    
    

}
