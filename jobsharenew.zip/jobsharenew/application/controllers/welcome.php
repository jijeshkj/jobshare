<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Welcome extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('pagination');
        $this->load->model('AdminJobModel', 'model');
        $this->load->database();
    }

    public function admin() {
        //$this->load->view('NiceAdmin/header');
        $this->load->view('NiceAdmin/login');
        //$this->load->view('NiceAdmin/footer');
    }

    public function index() {
        $this->load->view('jobshare/header');
        $data = $this->model->getCategory();
        foreach ($data as $value) {
            $pass[] = array('id' => $value->id, 'name' => $value->category_name);
        }
        $locations = $this->model->viewLocation();
        foreach ($locations as $values) {
            $passloc[] = array('id' => $values->id, 'name' => $values->location_name);
        }
        $jobtitles = $this->model->jobtitles();

        foreach ($jobtitles as $records) {
            $jobsdata[] = array('title' => $records->job_title, 'company' => $records->company_name);
        }
        $this->load->view('jobshare/index', array('value' => json_encode($pass), 'location' => $passloc, 'jobs' => $jobsdata));

        //$this->load->view('NiceAdmin/footer');
    }

    public function searchJob() {


        $cat = $_POST['name'];


        $loc = ($_POST['where']);



        /* pagination link */
        $config = array();
        $config["base_url"] = base_url() . "welcome/searchJob";
        $total_row = $this->model->record_count($cat, $loc);
        $config["total_rows"] = $total_row;
        $config["per_page"] = 4;
        $config['use_page_numbers'] = TRUE;
        $config['num_links'] = $total_row;
        $config['cur_tag_open'] = '&nbsp;<a class="current">';
        $config['cur_tag_close'] = '</a>';
        $config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';

        $this->pagination->initialize($config);
        if ($this->uri->segment(3)) {
            $page = ($this->uri->segment(3));
        } else {
            $page = 1;
        }

        $data = $this->model->searchJob($config["per_page"], $cat, $loc);
        $str_links = $this->pagination->create_links();
        $links = explode('&nbsp;', $str_links);

        $categories = $this->model->getCategory();
        $locations = $this->model->viewLocation();
        $qalifications = $this->model->viewQualification();
        $jobtitle = $this->model->jobtitles();
        $this->load->view('jobshare/searchresults', array('value' => $data, 'cat' => $categories,
            'locations' => $locations, 'qualification' => $qalifications, 'job_titles' => $jobtitle, 'links' => $links));
    }

    public function searchJob1() {
        if (isset($_POST['category'])) {
            $cat = $_POST['category'];
        }
        if (isset($_POST['location'])) {
            $location = $_POST['location'];
        }
        if (isset($_POST['qualification'])) {
            $qualification = $_POST['qualification'];
        }


        $data = '';
        $records = $this->model->getAllRecords();
        $datas = array();

        if ($records) {
            $dt = array();
            $flag = false;
            if($cat){
            foreach ($cat as $category) {
                $StudentaKey = array_keys(array_column($records, 'cat_id'), $category);
                if ($StudentaKey && !$flag) {
                    foreach ($StudentaKey as $recordkey) {
                        array_push($dt, $records[$recordkey]);
                    }
                } else {
                    $flag = true;
                    $dt = array();
                }
            }
            }
            
            
            
            $datas = $dt;




//            foreach ($records as $key=> $record) {
//                $categorykey = array_search($record->cat_id, $cat);
//              
//                if(is_numeric($categorykey)){
//                    array_push($datas, $record);
//                }
//            }
        }

        /* pagination link */
        $config = array();
        $config["base_url"] = base_url() . "welcome/searchJob";
        $total_row = count($datas);
        $config["total_rows"] = $total_row;
        $config["per_page"] = 4;
        $config['use_page_numbers'] = TRUE;
        $config['num_links'] = $total_row;
        $config['cur_tag_open'] = '&nbsp;<a class="current">';
        $config['cur_tag_close'] = '</a>';
        $config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';

        $this->pagination->initialize($config);
        if ($this->uri->segment(3)) {
            $page = ($this->uri->segment(3));
        } else {
            $page = 1;
        }

        //$data = $this->model->searchJob1($config["per_page"], $cat);
        $str_links = $this->pagination->create_links();
        $links = explode('&nbsp;', $str_links);

        $categories = $this->model->getCategory();
        $locations = $this->model->viewLocation();
        $qalifications = $this->model->viewQualification();
        $jobtitle = $this->model->jobtitles();
        $this->load->view('jobshare/searchresults', array('value' => $datas, 'cat' => $categories,
            'locations' => $locations, 'qualification' => $qalifications, 'job_titles' => $jobtitle, 'links' => $links));
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */