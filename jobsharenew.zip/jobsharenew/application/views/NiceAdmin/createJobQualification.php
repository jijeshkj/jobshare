          <div class="form quick-post">
                                      <!-- Edit profile form (not working)-->
                                      <form class="form-horizontal">
                                          <!-- Title -->
                                          <div class="form-group">
                                           
                                            <div class="col-lg-offset-2"> 
                                             
                                            </div>
                                          </div>   
                                          <!-- Content -->
                                                                 
                                          <!-- Cateogry -->
                                                 <div class="form-group">
                                           
                                            <div class="col-lg-offset-2"> 
                                             <h1>Add New Job Qualification</h1>
                                            </div>
                                          </div>         
                                          <!-- Tags -->
                                          <div class="form-group">
                                            <label class="control-label col-lg-3" for="tags"> name</label>
                                            <div class="col-lg-2">
                                              <input type="text" class="form-control" name='qualification' id="tags">
                                            </div>
                                            <div class="col-lg-2">
                                              <button type="submit" class="btn btn-primary">Save</button>
                                            </div>
                                          </div>
                                          
                                          <!-- Buttons -->
                                          <div class="form-group">
                                             <!-- Buttons -->
                    
                                          </div>
                                      </form>
                                    </div>