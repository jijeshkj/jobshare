<section class="panel">
    <div class="panel-body progress-panel">
        <div class="row">
            <div class="col-lg-8 task-progress pull-left">
                <h1>To Do Everyday</h1>                                  
            </div>
            <div class="col-lg-4">
                <span class="profile-ava pull-right">
                    <img alt="" class="simple" src="img/avatar1_small.jpg">
                    Jenifer smith
                </span>                                
            </div>
        </div>
    </div>
    <div class="row">
        <center><h3><strong>Category List</strong></h3></center></div>

    <center><div class="panel-body progress-panel" align="center" style="width: 700px">

            <table class="table table-condensed">
                <th>Sl No</th>
                <th>Category Name</th>
                <th>Action</th>

                <?php
                $j = 1;
                foreach ($category as $key => $values) {
                    ?>
                    <tr > <td><?php echo $j; ?></td>
                        <td style="width: 150px"><label class='lblrole badge bg-important' id=lblrole<?php echo $j; ?>><?php echo $values->category_name; ?></label>
                            <input type='text' id='editrole<?php echo $j; ?>' class="hiddenrole form-control" value="<?php echo $values->category_name; ?>"  >
                            <label class='lbError' id='lblerr<?php echo $j; ?>'></label></td>

                        <td><a href='javascript:void(0)' altCtrlID="<?php echo $values->id; ?>"  altrowID="<?php echo $j; ?>"  class='editrolelink' id="editrolelink<?php echo $j; ?>" >edit<i class='fa fa-edit'></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
                                <a href='javascript:void(0)'altCtrlID="<?php echo $values->id; ?>"   altrowID="<?php echo $j; ?>"  class='updaterolelink' id="updaterolelink<?php echo $j; ?>" >update</a>&nbsp;&nbsp; 
                            <a href='javascript:void(0)' altCtrlID="<?php echo $values->id; ?>"  altrowID="<?php echo $j; ?>"  class='cancelrolelink' id="cancelroleId<?php echo $j; ?>">cancel</a></td></tr><?php $j++; ?>

                    <?php
                }
                ?>

            </table>

        </div></center></section>
<script>
    $(".updaterolelink").hide();
    $(".cancelrolelink").hide();
    $(".hiddenrole").hide();
    $(".updateloclink").hide();
    $(".cancelloclink").hide();
    $(".hiddenloc").hide();

    $(".editrolelink").click(function () {
        var rowID = $(this).attr('altrowID');
        $("#lblrole" + rowID).hide();
        $("#editrole" + rowID).show();
        $(".editrolelink").hide();
        $(".updaterolelink").hide();
        $(".cancelrolelink").hide();
        $("#updaterolelink" + rowID).show();
        $("#cancelroleId" + rowID).show();
    });
    $(".cancelrolelink").click(function () {
        var rowID = $(this).attr('altrowID');
        $("#lblrole" + rowID).show();
        var labelvalue = $("#lblrole" + rowID).text();
        $("#editrole" + rowID).val(labelvalue);
        $("#editrole" + rowID).hide();
        $(".editrolelink").show();
       
        $(".updaterolelink").hide();
        $(".cancelrolelink").hide();
    });
    $(".updaterolelink").click(function () {
        var id = $(this).attr('altCtrlID');
        var rowID = $(this).attr('altrowID');
        var name = $("#editrole" + rowID).val();
        updatecategory(id, name, rowID);
    });

   

    function updatecategory(id, name, rowID) {
        if (name != '' && id != '') {
            $.ajax({
                type: "POST",
                url: '<?php echo base_url('JobController/updateCategory'); ?>',
                data: {'category': name, 'id': id},
                'success'
                        : function (data) {
                            window.location.reload();
                        },
                'error': function (data) {
                }
            });
        } else {
            $('.lbError').text('');
            $('.lbError').show();
            $('#lblerr' + rowID).text('is mandatory').fadeOut(8000);
        }
    }


   

</script>