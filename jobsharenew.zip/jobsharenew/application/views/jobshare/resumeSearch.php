
<div id="wrap" >

    <!-- Fixed navbar -->

    <!-- Begin page content -->
    <div class="container" >
        <div class="page-header">
            <h2 style="color: #006699"> Find Resume</h2>
        </div>
        <div class="col-lg-4">
            <label class="caption" style="color: #006699">what</label>
            <input type="text" id="tags" class="form-control">                 

        </div>
        <!--            <div class="col-lg-4">
                        <label class="caption"  style="color: #006699">where</label>
                        <input type="text" id ="where" class="form-control">    
                    </div>-->
        <div class="col-lg-2">
            <label class="caption">&nbsp;</label>
            <button type="button" class="form-control btn-primary" id="jobshare"> Search</button>
        </div>
        <div id="searchresults" ></div>
    </div>
</div>
<script>


    var data =<?php echo json_encode($value); ?>;
    var len = data.length;

    var catarray = [];
    for (var i = 0; i < len; i++) {
        var cat = data[i]['name'];
        catarray.push(cat);
    }
    var resumes =<?php echo json_encode($uploadedvalues); ?>;
    var resumeslen = resumes.length;

    for (var j = 0; j < resumeslen; j++) {
        var resume = resumes[j]['name'];
        alert(resume.length)
        if (resume.length > 1) {
            for (var k = 0; k < resume.length; k++) {
                catarray.push(resume[k]);
            }
        } else {
            catarray.push(resume);
        }

    }
//    alert(JSON.stringify(catarray))

    $("#tags").autocomplete({
        minLength: 0,
        maxLength: 10,
        source: catarray,
        select: function (e, ui) {
        },
        change: function (e, ui) {
        }
    });


            $("#jobshare").on('click', function () {
            
            var name = $("#tags").val();
            searchJob( name);
        });


    function searchJob(name) {
        $.ajax({
            method: "POST",
            type: "html",
            url: '<?php echo base_url('ResumeController/searchResume'); ?>',
            data: {name: name},
            success: function (data) {
                $("#searchresults").html("");
                $("#searchresults").append(data);
            },
            error: function (data) {
            }
        });

    }
    
       $(document).on('click', '#pagination a', function (e) {
            // alert('hhh');
            e.preventDefault();
            var url = $(this).attr('href');
            var name = $("#tags").val();
            var where = $("#where").val();
            $.ajax({
                method: "POST",
                type: "html",
                url: url,
                data: {name: name, where: where},
                success: function (data) {
                    $("#searchresults").html("");
                    $("#searchresults").append(data);
                },
                error: function (data) {
                }
            });

        });

    
    

</script>