<!DOCTYPE html>

<body>
    <!-- Wrap all page content here -->
    <div id="wrap" >
        <!-- Fixed navbar -->
        <!-- Begin page content -->
        <div class="container" >
            <div class="page-header">
                <h1>Job Share</h1>
            </div>
            <div class="col-lg-4">
                <label class="caption" style="color: #006699">what</label>
                <input type="text" id="tags" class="form-control">                 
                job title,category, keywords 
            </div>
            <div class="col-lg-4">
                <label class="caption"  style="color: #006699">where</label>
                <input type="text" id ="where" class="form-control">    
            </div>
            <div class="col-lg-2">
                <label class="caption">&nbsp;</label>
                <button type="button" class="form-control btn-primary" id="jobshare">Job Search</button>
            </div>
            <div id="searchresults" ></div>
        </div>
    </div>


    <div id="footer">
        <div class="container">
            <p class="text-muted credit">Example courtesy <a href="http://martinbean.co.uk">Martin Bean</a> and <a href="http://ryanfait.com/sticky-footer/">Ryan Fait</a>.</p>
        </div>
    </div>

    <!-- script references -->

</body>
</html>
<style>
    .ui-autocomplete { height: 200px; overflow-y: scroll; overflow-x: hidden;}
</style>

<script>
    $(function () {
        var data =<?php echo $value; ?>;
        //  var data =<?php echo json_encode($value); ?>;
        var len = data.length;
        var catarray = [];
        for (var i = 0; i < len; i++) {
            var cat = data[i]['name'];
            catarray.push(cat);
        }
        var datalolc =<?php echo json_encode($location); ?>;
        var lenloc = datalolc.length;
        var locarray = [];
        for (var i = 0; i < lenloc; i++) {
            var loc = datalolc[i]['name'];
            locarray.push(loc);
        }
        var jobs =<?php echo json_encode($jobs); ?>;
        var jobloc = jobs.length;

        for (var i = 0; i < jobloc; i++) {
            var jobtitle = jobs[i]['title'];
            var company = jobs[i]['company'];
            catarray.push(jobtitle);
            catarray.push(company);
        }
        $("#tags").autocomplete({
            minLength: 0,
            maxLength: 10,
            source: catarray,
            select: function (e, ui) {
            },
            change: function (e, ui) {
            }
        });
//        $("#tags").focus(function () {
//            $(this).autocomplete("search");
//        });

        $("#where").autocomplete({
            minLength: 0,
            source: locarray,
            select: function (e, ui) {
            },
            change: function (e, ui) {
            }
        });
        $("#where").focus(function () {
            $(this).autocomplete("search");
        });

        $("#jobshare").on('click', function () {
            var name = $("#tags").val();
            var where = $("#where").val();
            searchJob(name, where);
        });

        function searchJob(name, where) {
            $.ajax({
                method: "POST",
                type: "html",
                url: '<?php echo base_url('welcome/searchJob'); ?>',
                data: {name: name, where: where},
                success: function (data) {
                    $("#searchresults").html("");
                    $("#searchresults").append(data);
                },
                error: function (data) {
                }
            });

        }


        $(document).on('click', '#pagination a', function (e) {
            // alert('hhh');
            e.preventDefault();
            var url = $(this).attr('href');
            var name = $("#tags").val();
            var where = $("#where").val();
            $.ajax({
                method: "POST",
                type: "html",
                url: url,
                data: {name: name, where: where},
                success: function (data) {
                    $("#searchresults").html("");
                    $("#searchresults").append(data);
                },
                error: function (data) {
                }
            });

        });



    });
</script>