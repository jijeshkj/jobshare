<script src="<?php echo base_url('assets/js/jquery-ui-1.10.4.min.js'); ?>"></script>
<script src="<?php echo base_url(); ?>/assets/js1/bootstrap.min.js"></script>
<script src="<?php echo base_url('assets/js/autocomplete/jquery-1.12.4.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/autocomplete/jquery-ui.js'); ?>"></script>
<script src="<?php echo base_url('assets/js1/bootstrap.min.js'); ?>"></script>
<link rel="stylesheet" href="<?php echo base_url('assets/css/autocomplete/jquery-ui.css'); ?>">
<link href="<?php echo base_url(); ?>/assets/css1/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>/assets/css1/styles.css" rel="stylesheet">
<style>
    .centerarrange{
        margin-top: 10%;

    }


</style>

<div class="col-lg-12">
    <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
    <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
    <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
</div>


<div class="col-lg-3"></div>
<div class="col-lg-9">
    <h3 align="left" class="caption" style="color: #006699"><strong></strong></h3>
    <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
</div>
<?php if ($this->session->flashdata('message')) { ?>
    <div class="alert alert-success centerarrange col-lg-12">      
        <center> <?php echo $this->session->flashdata('message') ?><br><br><br>
        
            <a href="<?php echo base_url('JobshareCOntroller/resumeSearch');?>"> View Resumes</a>&nbsp;&nbsp;&nbsp;or&nbsp;&nbsp;&nbsp;
        <a href="<?php echo base_url('JobShareController/uploadResume');?>"> upload Resumes</a>
        </center>
        
        
    </div>
<?php } ?>

