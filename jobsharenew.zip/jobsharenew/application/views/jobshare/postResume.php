<script src='//cdn.tinymce.com/4/tinymce.min.js'></script>

<script>
            tinymce.init({
            selector: '#mytextarea'
            });</script>
<div class="col-lg-12">
    <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
    <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
    <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
</div>


<div class="col-lg-3"></div>
<div class="col-lg-9">
    <h3 align="left" class="caption" style="color: #006699"><strong>Create My Resume</strong></h3>
    <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
</div>

<!--<div class="col-lg-5"> <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
</div>--><a href="<?php echo base_url('ResumeController/getResume'); ?>">Click here to Download Your Resume</a>
<div class="col-lg-3"></div>

<div class="col-lg-5" style="background-color: #E8E8E8;"  > 
    <div class="col-lg-11" > 
        <h4 align="left" class="caption" >Profile</h4></div>
    <div class="col-lg-1" >   <a href="javascript:void(0);" id="plus">
            <span class="glyphicon glyphicon-plus"></span>
        </a>  <a href="javascript:void(0);" id="minus">
            <span class="glyphicon glyphicon-minus"></span>
        </a></div>
    <form name="profileCreation" method="post" id="profileCreationForm">

        <div id="profile" class="col-lg-10">
            <h5 align="left" class="caption" style="color: #006699;">First Name</h5>
            <span class="lblerr" id="lblemail" align="left"></span>
            <input type="text" class="form-control" name="firstname">

            <h5 align="left" class="caption" style="color: #006699;">Last Name</h5>
            <span class="lblerr" id="lblemail" align="left"></span>
            <input type="text" class="form-control" name="lastname">
            <h5 align="left" class="caption" style="color: #006699;">Street Address</h5>
            <span class="lblerr" id="lblemail" align="left"></span>
            <input type="text" class="form-control" name="address">
            <h5 align="left" class="caption" style="color: #006699;">Pin Code </h5>
            <span class="lblerr" id="lblemail" align="left"></span>
            <input type="text" class="form-control" name="pincode">
            <h5 align="left" class="caption" style="color: #006699;">Phone Number</h5>
            <span class="lblerr" id="lblemail" align="left"></span>
            <input type="text" class="form-control" name="phonenumber">
            <h5 align="left" class="caption" style="color: #006699;">Whatsapp Number</h5>
            <span class="lblerr" id="lblemail" align="left"></span>
            <input type="text" class="form-control" name="whatsappnumber">
            <h5 align="left" class="caption" style="color: #006699;">Facebook Id</h5>
            <span class="lblerr" id="lblemail" align="left"></span>
            <input type="text" class="form-control" name="facebookid">
            <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
            <button type="button" class="btn-success form-control" style="width: 150px" id="profileButton" name="submit" value="profile">Save Profile</button>
            <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
        </div>
    </form>
</div>
<div class="col-lg-2" > </div>
<div class="col-lg-12" ><h5 align="left" class="caption" style="color: #006699">&nbsp;</h5></div>
<div class="col-lg-3"></div>
<div class="col-lg-5" style="background-color: #E8E8E8;"  > 
    <div class="col-lg-11" > 
        <h4 align="left" class="caption" >Work Experience</h4></div>
    <div class="col-lg-1" >   <a href="javascript:void(0);" id="experienceplus">
            <span class="glyphicon glyphicon-plus"></span>
        </a>  <a href="javascript:void(0);" id="experienceminus">
            <span class="glyphicon glyphicon-minus"></span>
        </a></div>
    <form id="experienceCreationForm" method="post">
        <div id="experience" class="col-lg-10">
            <div id="">
                <table id="tblexperience">
                    <th>
                    <h5 align="left" class="caption" style="color: #006699;">Job Title</h5>  
                    </th>
                    <th>
                    <h5 align="left" class="caption" style="color: #006699;">Experience</h5>  
                    </th>
                    <th>
                    </th>
                    <tr>
                        <td width="50%" >
                            <input type="text" placeholder="Job Title" class="form-control" name="jobtitle[]"> 
                        </td>
                        <td width="50%">
                            <input type="text" placeholder="Experience" class="form-control" name="experience[]"></td><td><span style="color: red"></span> 
                        </td>

                        <td style="width: 10px"></td>
                        <td colspan="2">
                            <strong><a href="javascript:void(0);" id="addrowexperience" class="glyphicon-plus addrow"> </a></strong>
                        </td>
                    </tr>
                </table>
                <div class="col-lg-10">
                    <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
                    <input type="hidden" name="submit" value="experience">
                    <button type="button" class="btn-success form-control" style="width: 150px" name="submit" value="experience" id="experiencebutton">Save Experience</button>

                </div>
                <div class="col-lg-10"><h5 align="left" class="caption" style="color: #006699">&nbsp;</h5></div>
            </div>

        </div></form>
</div>
<div class="col-lg-2" > </div>
<div class="col-lg-12" ><h5 align="left" class="caption" style="color: #006699">&nbsp;</h5></div>
<div class="col-lg-3"></div>
<div class="col-lg-5" style="background-color: #E8E8E8;"  > 
    <div class="col-lg-11" > 
        <h4 align="left" class="caption" >Education</h4></div>
    <div class="col-lg-1" >   <a href="javascript:void(0);" id="educationplus">
            <span class="glyphicon glyphicon-plus"></span>
        </a><a href="javascript:void(0);" id="educationminus">
            <span class="glyphicon glyphicon-minus"></span>
        </a></div>
    <div id="education">
        <form id="EducationForm" method="post">
            <table id="tbleducation">
                <th>
                <h5 align="left" class="caption" style="color: #006699;">Education</h5>  
                </th>
                <th>
                </th>
                <tr>
                    <td width="45%" >
                        <input type="text" placeholder="eg :Degree" class="form-control" name="education[]"> 
                    </td>

                    <td style="width: 10px"></td>
                    <td colspan="2">
                        <strong><a href="javascript:void(0);" id="addrow" class="glyphicon-plus addrow"> </a></strong>

                    </td>
                </tr>
            </table>



            <div class="col-lg-10">
                <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
                <input type="hidden" name="submit" value="education">
                <button type="button" class="btn-success form-control" style="width: 150px" name="submit" value="education" id="education">Save Education</button>
                <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
            </div>
        </form>

    </div>
</div>

<div class="col-lg-2" > </div>
<div class="col-lg-12" ><h5 align="left" class="caption" style="color: #006699">&nbsp;</h5></div>
<div class="col-lg-3"></div>
<div class="col-lg-5" style="background-color: #E8E8E8;"  > 

    <div class="col-lg-11" > 
        <h4 align="left" class="caption" >Additional Information</h4></div>
    <div class="col-lg-1" >   <a href="javascript:void(0);" id="additionplus">
            <span class="glyphicon glyphicon-plus"></span>
        </a><a href="javascript:void(0);" id="additionminus">
            <span class="glyphicon glyphicon-minus"></span></a></div>
    <form id="Additional" method="post">
        <div id="Additional" class="col-lg-10">
            <h5 align="left" class="caption" style="color: #006699;">Additional Informations</h5>
            <span class="lblerr" id="lblemail" align="left"></span>
            <textarea name="description" id="mytextarea" style="height:150px"></textarea>

            <div class="col-lg-10">
                <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
                <input type="hidden" name="submit" value="additional">
                <button type="button" class="btn-success form-control" style="width: 150px" id="additionalbutton">Save </button>
                <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
            </div>
        </div>


    </form>

</div>
<script>
            $("#profile").hide();
            $("#minus").hide();
            $("#experienceminus").hide();
            $("#experience").hide();
            $("#educationminus").hide();
            $("#education").hide();
            $("#additionminus").hide();
            $("#Additional").hide();
            $("#plus").click(function () {
    $("#profile").show();
            $("#minus").show();
            $("#plus").hide();
    });
            $("#minus").click(function () {
    $("#profile").hide();
            $("#minus").hide();
            $("#plus").show();
    });
            $("#experienceplus").click(function () {
    $("#experience").show();
            $("#experienceminus").show();
            $("#experienceplus").hide();
    });
            $("#experienceminus").click(function () {
    $("#experience").hide();
            $("#experienceminus").hide();
            $("#experienceplus").show();
    });
            $("#educationplus").click(function () {
    $("#education").show();
            $("#educationminus").show();
            $("#educationplus").hide();
    });
            $("#educationminus").click(function () {
    $("#education").hide();
            $("#educationminus").hide();
            $("#educationplus").show();
    });
            $("#additionplus").click(function () {
    $("#Additional").show();
            $("#additionminus").show();
            $("#additionplus").hide();
    });
            $("#additionminus").click(function () {
           $("#Additional").hide();
            $("#additionminus").hide();
            $("#additionplus").show();
    });
            $(".addrow").click(function () {
    AddRow();
    });
            $(".delete").click(function () {
    $(this).closest("tr").remove();
    });
            function AddRow()
            {
            $('#tbleducation').append("<tr><td width='30%' ><input type='text' placeholder='eg :Degree' class='form-control' name='education[]'></td>"
                    + "<td colspan='2'></td><td>"
                    + "<strong><a href='javascript:void(0);' id='delete' class='glyphicon-minus delete'></a></strong>"
                    + "</td></tr>");
                    $(".delete").click(function () {
            $(this).closest("tr").remove();
            });
            }
    $(".addrow").click(function () {
    addrowexperience();
    });
            function addrowexperience()
            {
            $('#tblexperience').append("<tr><td width='30%' ><input type='text' placeholder='Job Title' class='form-control' name='jobtitle[]'>"
                    + " </td><td width='30%'><input type='text' placeholder='Experience' class='form-control' name='experience[]'> </td><td>"
                    + "<strong><a href='javascript:void(0);' id='delete' class='glyphicon-minus delete'></a></strong>"
                    + "</td></tr>");
                    $(".delete").click(function () {
            $(this).closest("tr").remove();
            });
            }


    $("#profileButton").click(function () {
    var form = $("#profileCreationForm").serialize();
            saveProfile(form, 'profile');
    });
            function saveProfile(form, type) {
            $.ajax({
            url: '<?php echo base_url('ResumeController/saveProfile'); ?>',
                    type: 'POST',
                    data: form,
                    success: function (data) {
                  
                    alert('inserted succesfully');
                            switch (type) {
                    case 'profile':
                            $("#profile").hide();
                            $("#minus").hide();
                            $("#plus").show();
                            break;
                    case 'education':
                            $("#profile").hide();
                            $("#minus").hide();
                            $("#plus").show();
                            break;
                    case 'additional':
                            $("#Additional").hide();
                            $("#additionminus").hide();
                            $("#additionplus").show();
                            break;
                    }
                   
                    console.log(data);
                    }
            });
            }


    $("#experiencebutton").click(function () {
    var form = $("#experienceCreationForm").serialize();
            saveProfile(form, 'experience');
    });
            $("#education").click(function () {
    var form = $("#EducationForm").serialize();
            saveProfile(form, 'education');
    });
            $("#additionalbutton").click(function () {
    var form = $("#Additional").serialize();
            saveProfile(form, 'additional');
    });
//    function saveExperience() {
//        var form = $("#profileCreationForm").serialize();
//        $.ajax({
//            url: '<?php echo base_url('ResumeController/saveProfile'); ?>',
//            type: 'POST',
//            data: form,
//            success: function (data) {
//                console.log(data);
//            }
//        });
//    }



</script>