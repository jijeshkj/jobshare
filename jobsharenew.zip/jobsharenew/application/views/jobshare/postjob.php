<script src='//cdn.tinymce.com/4/tinymce.min.js'></script>

<script>
    tinymce.init({
        selector: '#mytextarea'
    });
</script>
<style>
    .lblerr{
        color:red;
    }
    .txtwidth{
        width:300px;

    }
</style>

<div class="container">
    <br><br>
</div>


<div class="container">
    <h1 style="color: #006699">Job Share</h1>
    <div class="col-lg-4"></div>
    <form method="post" action="<?php echo base_url('JobShareController/JobaddedProcess'); ?>" id="jobpostform">
        <div class="col-lg-9"  style="background-color: #E8E8E8;" id="companydetails">
            <h3  align="left">Post Job</h3>
            <h5  align="left">Company Details</h5>
            <div class="col-lg-5">
                <h5 align="left" class="caption" style="color: #006699;">Company Name</h5>
                <span class="lblerr" id="lblcompany" align="left"></span>
                <input type="text" id="companyname" placeholder="company name" name="companyname" class="form-control " >  
            </div>
            <div class="col-lg-5">
                <h5 align="left" class="caption" style="color: #006699;">New Applications Send Email</h5>
                <span class="lblerr" id="lblre-email"></span>
                <input type="text" id="re-email" name="email" placeholder="email" class="form-control txtwidth">  
            </div>
            <div class="col-lg-12">
                <h5 align="left" class="caption" style="color: #006699;">&nbsp;</h5> 
            </div>
            <div class="col-lg-5">
                <h5 align="left" class="caption" style="color: #006699">JobLocation</h5>
                <span class="lblerr" id="lblpasword"></span> 
                <table align="left">
                    <tr>
                        <td ><button type="button" style="width:100px"  id="india"  name="location" value="india" selected="true" class="btn-success form-control">india</button></td>
                        <td>&nbsp;</td>
                        <td> <button type="button" style="width:120px" id="outside" name="location" value="india"  class="btn-default form-control">Out Side India</button></td>
                    </tr>
                </table>
            </div>
            <div class="col-lg-5">
                <h5 align="left" class="caption" style="color: #006699">   What is the job title for this posting?</h5>
                <span class="lblerr" id="lbljobtitle"></span> 
                <input type="text"  name="jobtitle" placeholder="job title" id="jobtitle"  class="form-control">
            </div>
            <div class="col-lg-12">
                <h5 align="left" class="caption" style="color: #006699;">&nbsp;</h5> 
            </div>
            <div class="col-lg-5">
                <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>

                <select name="location" id="locationtext" class="form-control">
                    <option value="0" >--select--</option>
                    <?php
                    foreach ($locations as $key => $record) {
                        ?>
                        <option value="<?php echo $record->id; ?>" ><?php echo $record->location_name; ?></option>
                        <?php
                    }
                    ?>
                </select>
                <!--<input type="text"  name="location" placeholder="location" id="locationtext" class="form-control">-->
                
                <select name="location2" id="location" class="form-control">
                    <option value="0" >--select--</option>
                    <?php
                    foreach ($countries as $key => $records) {
                        ?>
                        <option value="<?php echo $records->id; ?>" ><?php echo $records->name; ?></option>
                        <?php
                    }
                    ?>
                </select>
            </div>
            <div class="col-lg-5">
                <h5 align="left" class="caption" style="color: #006699">Job Category</h5>
                 <span class="lblerr" id="lbljobcategory"></span> 
                <select name="category" id="category" class="form-control">
                    <option value="0" >--select--</option>
                    <?php
                    foreach ($category as $key => $values) {
                        ?>
                        <option value="<?php echo $values->id; ?>" ><?php echo $values->category_name; ?></option>
                        <?php
                    }
                    ?>
                </select>
            </div>
            <div class="col-lg-2">
                <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
            </div>
            <div class="col-lg-12">
                <h5 align="left" class="caption" style="color: #006699;">&nbsp;</h5> 
            </div>
            <div class="col-lg-9"></div>
            <div class="col-lg-3" ><h5 align="left" class="caption" style="color: #006699"></h5>
                <h5 align="left" class="caption" style="color: #006699">&nbsp</h5>
                <input type="submit" class="form-control btn-primary"  onclick="return validate()" value="Next">
                <div class="page-header">
                </div>
            </div>
        </div>  
        <div class="col-lg-9"  style="background-color: #E8E8E8;" id="jobdescription">

            <h3  align="left">Post Job</h3>
            <h5  align="left">Job Description</h5>
            <div class="col-lg-10">
                <h5 align="left" class="caption" style="color: #006699;">Job Title : <strong><span  id="title"></span></strong></h5>
            </div>
            <div class="col-lg-12" >
                <h5 align="left" class="caption" style="color: #006699">Description</h5>

                <textarea name="description" id="mytextarea" style="height:150px"></textarea>
                <span class="lblerr" id="lblDesc"></span>
            </div>
            <div class="col-lg-2">
                <h5 align="left" class="caption" style="color: #006699">&nbsp</h5>
                <a href="" id="back">back</a>
            </div>
            <div class="col-lg-7"></div>
            <div class="col-lg-3" ><h5 align="left" class="caption" style="color: #006699"></h5>
                <h5 align="left" class="caption" style="color: #006699">&nbsp</h5>
                <input type="submit" class="form-control btn-primary"  onclick="return descriptionValidate()"value="Next" >
                <div class="page-header">
                </div>
            </div>

        </div>  
        <div class="col-lg-9"  style="background-color: #E8E8E8;" id="postjob">
            <h3  align="left">Post Job</h3>
            <h3  align="left">&nbsp;</h3>
            <p >Would you like to ask candidates to respond to any criteria entered below when they apply for your job?</p>
            <div class="col-lg-10">
                <h5 align="left" class="caption" style="color: #006699;">Job Title :</h5>
            </div>
            <div class="col-lg-6" >
                <h5 align="left" class="caption" style="color: #006699">Education level</h5>
                <select name="qualification" id="qualification" class="form-control">
                    <option value="0" >--select--</option>
                    <?php
                    foreach ($qualifications as $key => $values) {
                        ?>
                        <option value="<?php echo $values->id; ?>" ><?php echo $values->quals_name; ?></option>
                        <?php
                    }
                    ?>
                </select>
            </div>
            <div class="col-lg-5">
                <h5 align="left" class="caption" style="color: #006699">What is the salary for this job? (optional)</h5>
                <input type="text"  name="salary" placeholder="salary/Month"  class="form-control">
            </div>
            <div class="col-lg-12" ></div>
            <div class="col-lg-6">
                <h5 align="left" class="caption" style="color: #006699">Experience</h5>
                <input type="text"  name="experience" placeholder="experience" id="locindia"  class="form-control">
            </div>
            <div class="col-lg-2">
                <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
                <select name="experienceType" id="location" class="form-control">
                    <option value="month" >--per/month--</option>
                    <option value="year" >--per/year--</option>
                </select>
            </div>
            <div class="col-lg-12"> <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
            </div>
            <div class="col-lg-1">
                <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
                <input type="checkbox">
            </div>
            <div class="col-lg-6">
                <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
                <a href="">Terms & Conditions</a>
            </div>
            <div class="col-lg-3" ><h5 align="left" class="caption" style="color: #006699"></h5>
                <h5 align="left" class="caption" style="color: #006699">&nbsp</h5>
                <input type="submit" class="form-control btn-primary"  onclick="return submitform()" value="Post Job" >
                <div class="page-header">
                </div>
            </div>
        </div>  
    </form>

</div>
<div class="col-lg-11">
    &nbsp;
</div>
<div class="col-lg-12">
    <a href="">Help Center</a>
</div>
<div class="col-lg-11">
    &nbsp;
</div>
<div class="col-lg-12">
    @2016 jobshare <a href="">Privacy and Terms</a>
</div>
</div>
<style>
    .ui-autocomplete { height: 200px; overflow-y: scroll; overflow-x: hidden;}
</style>
<script>

    $("#india").click(function () {
        $(this).removeClass('btn-default form-control');
        $(this).addClass('btn-success form-control');
        $('#outside').removeClass('btn-success form-control');
        $("#outside").addClass('btn-default form-control');

    });

    $("#outside").click(function () {
        $(this).removeClass('btn-default form-control');
        $(this).addClass('btn-success form-control');
        $('#india').removeClass('btn-success form-control');
        $("#india").addClass('btn-default form-control');
    });


    $("#location").hide();
    $("#india").click(function () {
        $("#location").hide();
        $("#locationtext").show();
    });
    $("#outside").click(function () {
        $("#location").show();
        $("#locationtext").hide();
    });
    $("#jobdescription").hide();
    $("#postjob").hide();
    function validate() {

        var flag = 0;
        $(".lblerr").show();
        if ($("#companyname").val() === '') {
            $("#companyname").focus();
            $("#lblcompany").text('is mandatory').fadeOut(3000);
            ;
            flag = 1;
        } else if ($("#re-email").val() === '') {
            $("#re-email").focus();
            $("#lblre-email").text('is mandatory').fadeOut(3000);
            ;
            flag = 1;
        }
        else if ($("#jobtitle").val() === '') {
            $("#jobtitle").focus();
            $("#lbljobtitle").text('is mandatory').fadeOut(3000);
            ;
            flag = 1;
        }
         else if ($("#category").val() === '0') {
            $("#category").focus();
            $("#lbljobcategory").text('is mandatory').fadeOut(3000);
            ;
            flag = 1;
        }
        
        
        else if ($("#password").val() === '') {
            $("#pasword").focus();
            $("#lblpasword").text("is mandatory");
            flag = 1;
        }else{
            flag=0;
        }
        if (flag === 1) {
            return false;
        } else if (flag === 0) {
            $("#companydetails").hide();
            $("#jobdescription").show();
            $("#title").text($("#jobtitle").val());
             return false;
            // return true;
        }
    }

    function descriptionValidate() {
        //  alert($("#mytextarea").val())
        $(".lblerr").show();

//        if ($("#mytextarea").val() === '') {
//
//            $("#mytextarea").focus();
//            $("#lblDesc").text("is mandatory").fadeOut(8000);
//        } else {
        $("#jobdescription").hide();
        $("#postjob").show();
        return false;
//        }

    }



    function submitform() {
        $(".lblerr").show();

        $("#jobpostform").submit();

    }


</script>
