<style>
    .lblerr{
        color: red;
    }
</style>
<div class="col-lg-12">
    <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
    <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
    <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
</div>


<div class="col-lg-3"></div>
<div class="col-lg-9">
    <h3 align="left" class="caption" style="color: #006699"><strong>Upload My Resume</strong></h3>
    <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
</div>

<div class="col-lg-3"></div>

<form name="resumeformn" enctype="multipart/form-data" action="<?php echo base_url('JobshareController/SaveuploadResume'); ?>" method="post" onsubmit="return validation()"> 
    <div class="col-lg-6" style="background-color: #E8E8E8;"  > 


        <div id="profile" class="col-lg-5">
            <h5 align="left" class="caption" style="color: #006699;"> Name</h5>
            <span class="lblerr" id="lblfirstname" align="left"></span>
            <input type="text" class="form-control" id="firstname" name="firstname">
        </div>
        <div id="profile" class="col-lg-5">
            <h5 align="left" class="caption" style="color: #006699;">Job Title</h5>
            <span class="lblerr" id="lbljobtitle" align="left"></span>
            <input type="text" class="form-control" id="jobtitle" name="jobtitle">
             </div>
        <div id="profile" class="col-lg-5">


            <h5 align="left" class="caption" style="color: #006699;">Whatsapp Number</h5>
            <span class="lblerr" id="lblwhatsa" align="left"></span>
            <input type="text" class="form-control" name="whatsappnumber">
             </div>
        <div id="profile" class="col-lg-5">
            <h5 align="left" class="caption" style="color: #006699;">Facebook Id</h5>
            <span class="lblerr" id="lblemail" align="left"></span>
            <input type="text" class="form-control" name="facebookid">
             </div>
        <div id="profile" class="col-lg-5">
            <h5 align="left" class="caption" style="color: #006699;">Upload file</h5>
            <input type="file" value="upload" name="file" class="file">
             </div>
        <div id="profile" class="col-lg-5">
            <h5 align="left" class="caption" style="color: #006699;">Total Year Of Experience</h5>
            <span class="lblerr" id="lblemail" align="left"></span>
            <select name="experience" class="form-control">
                <option>--select--</option>
                <?php
                for($i=0;$i<10;$i++){ ?>
                <option value=" <?php echo $i;?>"> <?php echo $i;?></option>
               <?php  }
                ?>
            </select>
        </div>
         <div id="profile" class="col-lg-5">
            <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
            <input type="submit" class="btn-success form-control" style="width: 150px"value="Save Profile">
            <h5 align="left" class="caption" style="color: #006699">&nbsp;</h5>
        </div>
        <div id="profile" class="col-lg-3"></div>
    </div>
</form>

<script>
    function validation() {
        $('.lblerr').show();
        if ($("#firstname").val() === '') {
            $("#firstname").focus();
            $("#lblfirstname").text('mandatory').fadeOut(3000);
            return false;
        } else if ($("#jobtitle").val() === '') {
            $("#jobtitle").focus();
            $("#lbljobtitle").text('mandatory').fadeOut(3000);
            return false;
        } else {
            return true;
        }

    }


</script>