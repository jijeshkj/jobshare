     
<style>
    .lblerr{
        color:red;
    }
</style>
<div class="container">
    <br><br>
</div>


<center><div class="container">

        <h1 style="color: #006699">Job Share</h1>

        <div class="col-lg-4"></div>
        <div class="col-lg-4" style="background-color: #E8E8E8;">
            <h3  align="left">Sign In</h3>
            <?php if ($this->session->flashdata('msg')) { ?>
                <div class="alert alert-success centerarrange col-lg-12">      
                    <center> <?php echo $this->session->flashdata('msg') ?>
                    <?php } ?>
                    <span class="lblerr" id="lblemail" align="left"></span>
                    <h5 align="left" class="caption" style="color: #006699;">Email</h5>
                    <input type="text" id="user" name="username" class="form-control">  
                    <h5 align="left" class="caption" style="color: #006699">Password</h5>

                    <input type="text" id="pwd" name="password" class="form-control">  

            <!--<input type="checkbox"  align="left">Keep me signed-in on this computer.-->
                    <label class="caption" style="color: #006699">&nbsp;</label>
                    <label class="caption" style="color: #006699">&nbsp;</label>
                    <button type="button" class="form-control btn-primary" onclick="return validate()" >Sign In</button>

                     <div class="col-lg-11">
                &nbsp;
            </div>

            </div>
            <div class="col-lg-11">
                &nbsp;
            </div>
            <div class="col-lg-12">
                <a href="<?php echo base_url('JobshareController/register'); ?>" > not a member ?create an account free</a>
            </div>
            <div class="col-lg-11">
                &nbsp;
            </div>
            <div class="col-lg-12">
                <a href="<?php echo base_url('LoginController/forgotPassword'); ?>" >For Your Password?</a>
            </div>
            <div class="col-lg-11">
                &nbsp;
            </div>
            <div class="col-lg-12">
                <a href="">Help Center</a>
            </div>
            <div class="col-lg-11">
                &nbsp;
            </div>
            <div class="col-lg-12">
                @2016 jobshare <a href="">Privacy and Terms</a>
            </div>



        </div></center>
<script>

    $('#pwd').keypress(function (e) {
        var key = e.which;
        if (key == 13)  // the enter key code
        {
            validate();
        }
    });



    function validate() {
        $(".lbError").show();
        if ($("#user").val() == '') {
            $("#user").focus();
            $("#lblerr").text('required').fadeOut(8000);
            return false;
        }
        else if ($("#pwd").val() == '') {
            $("#pwd").focus();
            $("#lblerrpwd").text('required').fadeOut(8000);
            return false;
        }
        else {
            loginProcess();
        }

    }


    function loginProcess() {
        $("#lblemail").show();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url('LoginController/login'); ?>',
            data: {'username': $("#user").val(), 'password': $('#pwd').val(), 'role': 'user'},
            //  async: false,
            dataType: 'json',
            success: function (data) {
                if (data == 'user') {
                    if ('<?php echo $value; ?>' === 'resume') {
                        window.location.href = "<?php echo base_url('JobshareController/Resume'); ?>";
                    } else {
                        window.location.href = "<?php echo base_url('JobshareController/postJob'); ?>";
                    }
                } else {
                    $("#lblemail").text(data).fadeOut(4000);
                }
            }
        });
    }
</script>