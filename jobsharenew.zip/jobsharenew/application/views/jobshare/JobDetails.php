
<br><br><br><br>

<div class="row">


    <div class="col-md-6 portlets">
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="pull-left">Job Details</div>
                <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="fa fa-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="fa fa-times"></i></a>
                </div>  
                <div class="clearfix"></div>
            </div>
            <div class="panel-body">
                <div class="padd">

                    <div class="form quick-post">
                        <!-- Edit profile form (not working)-->
                        <form class="form-horizontal">
                            <!-- Title -->
                            <div class="form-group">
                                <label class="control-label col-lg-3" for="title">Job Title</label>
                                <div class="col-lg-8"> 
                                   <?php echo $values[0]->job_title;?>
                                </div>
                            </div>   
                            <!-- Content -->
                            <div class="form-group">
                                <label class="control-label col-lg-3" for="content">Company Name</label>
                                <div class="col-lg-8">
                                   <?php echo $values[0]->company_name;?>
                                </div>
                            </div>     
                             <div class="form-group">
                                <label class="control-label col-lg-3" for="content">Company Email</label>
                                <div class="col-lg-8">
                                   <?php echo $values[0]->email;?>
                                </div>
                            </div>    
                            <!-- Cateogry -->
                            <div class="form-group">
                                <label class="control-label col-lg-3">Job Category</label>
                                <div class="col-lg-8">                               
                                 <?php echo $values[0]->category_name;?>
                                </div>
                            </div>    

                            <div class="form-group">
                                <label class="control-label col-lg-3">Job Location</label>
                                <div class="col-lg-8">                               
                                    <?php echo $values[0]->location_name;?>
                                </div>
                            </div>  
                            <div class="form-group">
                                <label class="control-label col-lg-3">Job Description</label>
                                <div class="col-lg-8">                               
                                     <?php echo $values[0]->description;?>
                                    
                                </div>
                            </div> 
                    
                            <!-- Tags -->
                            <div class="form-group">
                                <label class="control-label col-lg-3" for="tags">Qualification</label>
                                <div class="col-lg-8">
                                 <?php echo $values[0]->quals_name;?>   
                                </div>
                            </div>

                            <!-- Buttons -->
                            <div class="form-group">
                                <!-- Buttons -->
                                <div class="col-lg-offset-2 col-lg-9">
                                    <button type="submit" class="btn btn-primary">Apply Job</button>
                                    <button type="submit" class="btn btn-danger">Return To Home</button>

                                </div>
                            </div>
                        </form>
                    </div>


                </div>
                <div class="widget-foot">
                    <!-- Footer goes here -->
                </div>
            </div>
        </div>

    </div>

</div> 
<!-- project team & activity end -->

</section>
</section>
<!--main content end-->
</section>
