<style>ul {
        list-style-type: none;
    }</style>

<style type="text/css">
    img.img-circle.company-img{
        width:100px;
        padding-top: 20px;
    }
    .company{
        border:1px solid #f0f0f0;
    }
    ul.tsc_pagination li a
    {
        border:solid 1px;
        border-radius:3px;
        -moz-border-radius:3px;
        -webkit-border-radius:3px;
        padding:6px 9px 6px 9px;
    }
    ul.tsc_pagination li
    {
        padding-bottom:1px;
    }
    ul.tsc_pagination li a:hover,
    ul.tsc_pagination li a.current
    {
        color:#FFFFFF;
        box-shadow:0px 1px #EDEDED;
        -moz-box-shadow:0px 1px #EDEDED;
        -webkit-box-shadow:0px 1px #EDEDED;
    }
    ul.tsc_pagination
    {
        margin:4px 0;
        padding:0px;
        height:100%;
        overflow:hidden;
        font:12px 'Tahoma';
        list-style-type:none;
    }
    ul.tsc_pagination li
    {
        float:left;
        margin:0px;
        padding:0px;
        margin-left:5px;
    }
    ul.tsc_pagination li a
    {
        color:black;
        display:block;
        text-decoration:none;
        padding:7px 10px 7px 10px;
    }
    ul.tsc_pagination li a img
    {
        border:none;
    }
    ul.tsc_pagination li a
    {
        color:#0A7EC5;
        border-color:#8DC5E6;
        background:#F8FCFF;
    }
    ul.tsc_pagination li a:hover,
    ul.tsc_pagination li a.current
    {
        text-shadow:0px 1px #388DBE;
        border-color:#3390CA;
        background:#58B0E7;
        background:-moz-linear-gradient(top, #B4F6FF 1px, #63D0FE 1px, #58B0E7);
        background:-webkit-gradient(linear, 0 0, 0 100%, color-stop(0.02, #B4F6FF), color-stop(0.02, #63D0FE), color-stop(1, #58B0E7));
    }
</style>

<div class="container">
    <div class="clearfix"></div>
    <br><br>    

    <!--
    -->
    <div class="row">
        <form id="filteringform" name="filteringform" method="post">
            <div class="col-md-12">
                <div class="col-md-2">
                    <input type="button" id="submit" style="width: 100px;float: right" class="form-control btn-primary" value="Apply">

                    <ul><span><strong>Job Type</strong></span>
                        <?php foreach ($cat as $category) { ?>
                            <li class=""><span><input type="checkbox"  name="category[]" id="type"class="type" value="<?php echo $category->id ?>"><?php echo $category->category_name ?></span></li>
                        <?php } ?>
                    </ul>



                    <div>
                        <ul><span><strong>Job Location</strong></span>
                            <?php foreach ($locations as $loc) { ?>
                                <li><span><input type="checkbox" name="location[]" value="<?php echo $loc->id ?>"><?php echo $loc->location_name ?></span></li>
                            <?php } ?>
                        </ul>
                    </div>

                    <div>
                        <ul><span><strong>Qualifications</strong></span>
                            <?php foreach ($qualification as $qua) { ?>
                                <li><span><input type="checkbox" name="qualification[]" value="<?php echo $qua->id ?>"><?php echo $qua->quals_name ?></span></li>
                            <?php } ?>
                        </ul>
                    </div>

                    <div>
                        <ul><span><strong>Company Name</strong></span>
                            <?php foreach ($job_titles as $tiel) { ?>
                                <li><span><input type="checkbox"><?php echo $tiel->company_name ?></span></li>
                            <?php } ?>
                        </ul>
                    </div>

                    <!--                <div>
                                        <ul><span><strong>Job title</strong></span>
                    <?php foreach ($job_titles as $qua) { ?>
                                                                <li><span><input type="checkbox"><?php echo $qua->job_title ?></span></li>
                    <?php } ?>
                                        </ul>
                                    </div>-->


                </div>




                <div class="col-md-8">
                    <?php if (count($value > 0)) { ?>
                        <?php foreach ($value as $val) { ?>

                            <div class="row">
                                <div class="col-md-12 company">
                                    <!--                                <div class="col-md-2">
                                    <?php //if(isset($val->discription_image)){ ?>
                                                                        <img src="<?php echo base_url(); ?>uploads/<?php echo $val->discription_image; ?>.jpg" class="img-circle"/>
                                    <?php //}else{ ?>
                                                                        <img src="<?php echo base_url(); ?>/uploads/default.jpg" class="img-circle company-img"/>
                                    <?php //} ?>
                                                                    </div>-->
                                    <div class="col-md-8">
                                        <a href='javascript:void(0);' id="jobtitle" class="jobtitle" altCtrl=" <?php echo $val->id; ?>"> <h2><b><?php echo $val->job_title; ?></b></h2></a>
                                        <h6><?php echo $val->company_name; ?></h6>
                                        <p></p>
                                        <h6><?php echo $val->location_name; ?></h6>                    
                                    </div>


                                </div>
                            </div>
                            <br>

                            <?php
                        }
                    } else {
                        ?>
                        <div class="col-lg-12">No results found</div>
                    <?php } ?>
                    <div id="pagination">
                        <ul class="tsc_pagination">

                            <!-- Show pagination links -->
                            <?php
                            foreach ($links as $link) {
                                echo "<li>" . $link . "</li>";
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </form>
    </div>


</div>


<script>
    $(".jobtitle").click(function () {
        var alt = $(this).attr("altCtrl")
        JobDetails(alt);

    });

    $("#submit").click(function(){
        searchJob();
    });


    function searchJob() {
       
        $.ajax({
            method: "POST",
            type: "html",
            url: '<?php echo base_url('welcome/searchJob1'); ?>',
            data: $('#filteringform').serialize(),
            success: function (data) {

                $("#searchresults").html("");
                $("#searchresults").append(data);
            },
            error: function (data) {
            }
        });

    }




    function JobDetails(id) {
        var id = id.trim();
        window.open("<?php echo base_url('JobshareController/jobDetails') ?>/" + id);
    }








</script>