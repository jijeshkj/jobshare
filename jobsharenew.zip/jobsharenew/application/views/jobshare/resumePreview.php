<script src="<?php echo base_url('assets/js/jquery-ui-1.10.4.min.js'); ?>"></script>
<script src="<?php echo base_url(); ?>/assets/js1/bootstrap.min.js"></script>
<script src="<?php echo base_url('assets/js/autocomplete/jquery-1.12.4.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/autocomplete/jquery-ui.js'); ?>"></script>
<script src="<?php echo base_url('assets/js1/bootstrap.min.js'); ?>"></script>
<link rel="stylesheet" href="<?php echo base_url('assets/css/autocomplete/jquery-ui.css'); ?>">
<link href="<?php echo base_url(); ?>/assets/css1/bootstrap.min.css" rel="stylesheet">
<!--<link href="<?php echo base_url(); ?>/assets/css1/styles.css" rel="stylesheet">-->

    
<div id="profile" class="col-lg-10">
   
    <h4 align="left" class="caption" >Jijesh KJ</h4>
    <h6 > &nbsp;&nbsp;&nbsp;   Email:&nbsp;&nbsp;&nbsp;jijehs333@gmail.com</h6>
    <h6 > &nbsp;&nbsp;&nbsp;   Phone:&nbsp;&nbsp;&nbsp;8281245285</h6>
    <div id="profile" class="col-lg-7"></div> <div id="profile" class="col-lg-5"> <button type="button" class="btn-success form-control" style="width: 150px" id="profileButton" name="submit" value="profile">Download Resume</button></div>
    <h4> Career Objective : </h4> <p>To associate  with an organization that promises a creative career in progressive environment so to <br>
        enhance my knowledge and skills in the state of new technology and be a part of the team that excels in work towards the growth of organization. </p>
    <h4>Experience :</h4>
    <table border="1" class="table-bordered">
        <tr>
            <td >
                Job Title
            </td>
            <td >
                Year of Experience
            </td>

        </tr>
        <tr>
            <td style="width: 250px">dfsdsd</td>
            <td style="width: 200px">dfsdsd</td>
        </tr>
        <tr>
            <td style="width: 250px">dfsdsd</td>
            <td style="width: 200px">dfsdsd</td>
        </tr>
        <tr>
            <td style="width: 250px">dfsdsd</td>
            <td style="width: 200px">dfsdsd</td>
        </tr>

    </table>

    <h4>Educational Qualifications :</h4>

    <li>Betech</li>
    <li>Diploma</li>
    <li>Plus Two</li>
    <li>Sslc</li>
    
     <h4>Personal Profile: :</h4>
     <p>Name&nbsp;:&nbsp; Jijehs</p>
     <p>Facebook ID&nbsp;:&nbsp;jijesh kj </p>
     <p>Whatsapp Number&nbsp;:&nbsp; 8281245285</p>
     <p>Gender&nbsp;:&nbsp;Male</p>
     <p>Address&nbsp;:&nbsp;Ernakulam</p>
   
     
      <h4>Additional Details :</h4>
      <p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          jidj sdfsndfjsd sidfsdf sdfjsod fsdionfisd fisod fsodif sdfoisd fsdiofsd foisdfsdiofnsiodf sdionfiosd foisdf sd fsdo </p>
     
     
       <h4>Declaration:</h4>
      <p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          I hereby declare that all the details I have furnished above are true to the best of my knowledge and based on reliable certificates and documents.   </p>
      <br>
      <table width="100%">
          <tr width="40%">
              <td width="40%"> <h5>Chengannur</h5></td>
              <td width="40%"> <h5>Jijesh KJ</h5></td>
          </tr>
      </table>
     
</div>









