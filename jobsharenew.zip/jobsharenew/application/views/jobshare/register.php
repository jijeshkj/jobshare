<style>
    .lblerr{
        color:red;
    }
</style>

<div class="container">
    <br><br>
</div>


<center><div class="container">

        <h1 style="color: #006699">Job Share</h1>

        <div class="col-lg-4"></div>
        <form method="post" action="<?php echo base_url('JobShareController/registerProcess'); ?>" id="registerform">
            <div class="col-lg-4" style="background-color: #E8E8E8;">
                <h3  align="left">Sign In</h3>
                <h5 align="left" class="caption" style="color: #006699;">Email</h5>
                <span class="lblerr" id="lblemail" align="left"></span>
                <span class="lblerr" id="lblemail1" align="left"></span>
                <input type="email" id="email" name="email"  class="form-control">  
                <h5 align="left" class="caption" style="color: #006699;">Re-type Email</h5>
                <span class="lblerr" id="lblre-email"></span>
                <input type="email" id="re-email" name="re-email" class="form-control">  

                <h5 align="left" class="caption" style="color: #006699">Password</h5>
                <span class="lblerr" id="lblpasword"></span>

                <input type="password" id="password" name="password" class="form-control">  

                <input type="checkbox"  checked="" align="left">Keep me signed-in on this computer.
                <label class="caption" style="color: #006699">&nbsp;</label>
                <label class="caption" style="color: #006699">&nbsp;</label>
                <button type="button" class="form-control btn-primary" id="sign" onclick="return validate()" >Sign In</button>
              


            </div></form>
        <div class="col-lg-11">
            &nbsp;
        </div>
        <div class="col-lg-12">
            <a href="<?php echo base_url('JobshareController/login'); ?>" > Have an account ?Sign in</a>
        </div>
        <div class="col-lg-11">
            &nbsp;
        </div>
        <div class="col-lg-12">
            <A href=""> For Your Password?</a>
        </div>
        <div class="col-lg-11">
            &nbsp;
        </div>
        <div class="col-lg-12">
            <a href="">Help Center</a>
        </div>
        <div class="col-lg-11">
            &nbsp;
        </div>
        <div class="col-lg-12">
            @2016 jobshare <a href="">Privacy and Terms</a>
        </div>

    </div></center>
<script>

    $("#email").blur(function () {
        $(".lblerr").show();
        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
        var emailtest = emailReg.test($("#email").val());
        if (!emailtest) {
            $("#lblemail1").text('invalid email').fadeOut(3000);
            $('#sign').attr('disabled', true);
        } else {
            checkExist($("#email").val());
            $("#lblemail1").text('').fadeOut(3000);
            $('#sign').attr('disabled', false);
        }

    });
    function checkExist(val) {

        $.ajax({
            url: '<?php echo base_url('JobshareController/checkExist'); ?>',
            type: 'POST',
            data: {'user': val},
            success: function (data) {
                if (data) {
                    $("#lblemail1").text('email already exist').fadeOut(3000);
                    $('#sign').attr('disabled', true);
                } else {
                   // checkExist($("#email").val());
                    $("#lblemail1").text('').fadeOut(3000);
                    $('#sign').attr('disabled', false);
                }
            }
        });
    }

    function validate() {

        var flag = 0;
        $(".lblerr").show();
        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;


        if ($("#email").val() === '') {
            $("#email").focus();
            $("#lblemail").text('is mandatory').fadeOut(3000);
            flag = 1;
        }


        if ($("#re-email").val() === '') {
            $("#re-email").focus();
            $("#lblre-email").text('is mandatory');
            flag = 1;
        } else if ($("#email").val() !== $("#re-email").val()) {
            $("#re-email").focus();
            $("#lblre-email").text('field do not match').fadeOut(3000);
            flag = 1;
        }
        else if ($("#password").val() === '') {
            $("#pasword").focus();
            $("#lblpasword").text("is mandatory").fadeOut(3000);
            flag = 1;
        }

        if (flag === 1) {

            //  
            return false;
        } else if (flag === 0) {
            $("#registerform").submit();
            return true;
        }

    }





</script>
