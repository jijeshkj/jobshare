<style>
    .lblerr{
        color:red;
    }
</style>
<div class="container">
    <br><br>
</div>
<center><div class="container">
        <div class="col-lg-11">
            &nbsp;
        </div>
        <div class="col-lg-4">&nbsp;</div>
        <form name="forgotform" method="post" action="<?php echo base_url('LoginController/resetPassword');?>">
        <div class="col-lg-4" style="background-color: #E8E8E8;">
            <h3  align="left"></h3>
            <?php if ($this->session->flashdata('msg')) { ?>
                <div class="alert alert-success centerarrange col-lg-12">      
                    <center> <?php echo $this->session->flashdata('msg') ?>
                    <?php } ?>
                    <span class="lblerr" id="lblemail" align="left"></span>
                    <h5 align="left" class="caption" style="color: #006699;">New Password</h5>
                    <input type="text" id="user" name="username" class="form-control">  
                    <label class="caption" style="color: #006699">Re-Enter Password</label>
                      <input type="text" id="user" name="username" class="form-control">  
                    <div class="col-lg-11">
                        &nbsp;
                    </div>
                    <div class="col-lg-6"> 
                        <button type="button" class="form-control btn-primary" id="sign"  onclick="return validate()" >Send varification</button>
                    </div>
                    <div class="col-lg-11">
                        &nbsp;
                    </div>
            </div>
        </div></form>
    </div></center>

<script>
    $("#lblemail").show();
    $("#user").blur(function () {
        checkExist($("#user").val());
    });
    function checkExist(val) {
        $.ajax({
            url: '<?php echo base_url('JobshareController/checkExist'); ?>',
            type: 'POST',
            data: {'user': val},
            success: function (data) {
                if (data) {
                    $("#lblemail1").text('').fadeOut(3000);
                    $('#sign').attr('disabled', false);
                } else {
                    $("#lblemail").text('email not registered').fadeOut(3000);

                    $('#sign').attr('disabled', true);
                }
            }
        });
    }

    function validate() {
        if ($("#user").val() === '') {
            $("#lblemail").text('required').fadeOut(3000);
            return false;
        }else{
            return true;
        }
    }







</script>

