
<style>
    .lblerr{
        color:red;
    }
    .txtwidth{
        width:300px;

    }
</style>

<div class="container">
    <br><br>
</div>



<script>

    $("#back").click(function () {
        window.history.back();
    });
    $("#location").hide();
    $("#india").click(function () {
        $("#location").hide();
        $("#locationtext").show();
    });

    $("#outside").click(function () {
        $("#location").show();
        $("#locationtext").hide();
    });
    function validate() {

        var flag = 0;
        $(".lblerr").show();
        if ($("#email").val() === '') {
            $("#email").focus();
            $("#lblemail").text('is mandatory');
            flag = 1;
        } else if ($("#re-email").val() === '') {
            $("#re-email").focus();
            $("#lblre-email").text('is mandatory');
            flag = 1;
        }
        else if ($("#password").val() === '') {
            $("#pasword").focus();
            $("#lblpasword").text("is mandatory");
            flag = 1;
        }

        if (flag === 1) {

            //  
            return false;
        } else if (flag === 0) {
            $("#registerform").submit();
            return true;
        }

    }


</script>
