

<body background="<?php echo base_url(); ?>/assets/img/jamon-slider-02-construction-plans - Copy (2).jpg" >
    <br> <br> <br> <br> <br> <br> <br> <br>
    <div id="profile" class="col-lg-12">&nbsp;</div>
    <div class="col-lg-4"> </div>
<div class="col-lg-8"> 
    <strong><h3 style="color: red">Create or Upload Your Resume For Better Future</h3></strong>
</div>
<div  class="col-lg-12">&nbsp;</div>
</div> 

<div  class="col-lg-12">&nbsp;

</div>
</div>
<div  class="col-lg-2">
</div>
<div  class="col-lg-2">
</div>
<div  class="col-lg-2">
    <button type="button" class="btn-success form-control" id="upload" style="width: 150px">Upload Resume</button>
</div>
<div  class="col-lg-1">
    <strong>OR</strong>
</div>
<div  class="col-lg-5">
    <button type="button" class="btn-success form-control" id="create" style="width: 150px">Create Resume</button>
</div>
</body>


<script>
    
    $("#create").click(function(){
        window.location.href="<?php echo base_url('JobShareController/postResume');?>";
    });
     $("#upload").click(function(){
        window.location.href="<?php echo base_url('JobShareController/uploadResume');?>";
    })
    
</script>