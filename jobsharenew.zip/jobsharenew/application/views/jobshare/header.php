<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <title>JobShare</title>
        <meta name="generator" content="Bootply" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link href="<?php echo base_url(); ?>/assets/css1/bootstrap.min.css" rel="stylesheet">
        <!--[if lt IE 9]>
                <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <link href="<?php echo base_url(); ?>/assets/css1/styles.css" rel="stylesheet">
    </head>
    <style>
        #col{
            color: white;
        }
    </style>
    <script src="<?php echo base_url('assets/js/jquery-ui-1.10.4.min.js'); ?>"></script>
    <script src="<?php echo base_url(); ?>/assets/js1/bootstrap.min.js"></script>
    <script src="<?php echo base_url('assets/js/autocomplete/jquery-1.12.4.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/autocomplete/jquery-ui.js'); ?>"></script>
     <script src="<?php echo base_url('assets/js1/bootstrap.min.js'); ?>"></script>
    <!--<script src="<?php echo base_url('assets/js1/tinymce.min.js'); ?>"></script>-->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/autocomplete/jquery-ui.css'); ?>">
    <div class="navbar navbar-default navbar-fixed-top" style="background-color: #006699"  >
        <div  >
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse"  >
                <ul class="nav navbar-nav col-lg-10" >
                    <li class="active"><a href="<?php echo base_url('welcome/index'); ?>" id="col">FInd Jobs</a></li>
                    <li><a href="<?php echo base_url('JobshareController/resumeSearch'); ?>" id="col">Find  Resumes</a></li>
                     <?php if ($this->session->userdata('username')) { ?> 
                    <li><a href="<?php echo base_url('JobShareController/postJob'); ?>" id="col">Employers/Post Job</a></li>
                    <?php } else { ?>
                        <li><a href="<?php echo base_url('JobShareController/login'); ?>" id="col">Employers/Post Job</a></li>    
                        <?php } ?>

                </ul>
                <ul class="nav navbar-nav col-lg-2" >
                    <!--<li><a href="<?php echo base_url('JobShareController/postResume'); ?>" id="col">post your resume</a></li>-->
                     <?php if ($this->session->userdata('username')) { ?> 
                   <li><a href="<?php echo base_url('JobShareController/Resume'); ?>" id="col">post your resume</a></li>
                    <?php } else { ?>
                        <li><a href="<?php echo base_url('JobShareController/login'); ?>/resume" id="col">post your resume</a></li>    
                        <?php } ?>
                    
                    <?php if ($this->session->userdata('username')) { ?> 
                        <li><a href="<?php echo base_url('LoginController/logout'); ?>" id="col">logout</a></li>
                    <?php } else { ?>
                        <li><a href="<?php echo base_url('JobShareController/login'); ?>" id="col">login</a></li>    
                        <?php } ?>
                </ul>
            </div><!--/.nav-collapse -->
        </div>
    </div>

