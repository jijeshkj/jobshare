<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class ResumeModel extends CI_Model {

    public function saveProfile($data) {
        return $this->db->insert('jobshare_resumes', $data);
    }

    function existRecord($user) {
        $this->db->where('userID', $user);
        $query = $this->db->get('jobshare_resumes');
        if ($query->num_rows() > 0) {
            return $query->result();
        }
    }

    function updateProfile($data, $userId) {
        $this->db->where('id', $userId);
        return $this->db->update('jobshare_resumes', $data);
    }

    function getCreatedResumes() {
        $this->db->where('completed_status', 'commpleted');
        $query = $this->db->get('jobshare_resumes');
        if ($query->num_rows() > 0) {
            return $query->result();
        }
    }

    function getResumes() {
        $this->db->select('id,JobTitle');
        $this->db->from('jobshare_resumes');
        $this->db->where('status',0);
        $query = $this->db->get();
        return $query->result();
    }
    
    
    
    function getUploadedResumes() {
        $this->db->select('id,JobTitle');
        $this->db->from('jobshare_resumes');
        $this->db->where('status',1);
        $query = $this->db->get();
        return $query->result();
    }
    
      function searchResumes($limit, $cat) {

        //  die('dsfd');
        $this->db->limit($limit);
        //$array_name = array('job_title' => $cat, 'company_name' => $cat, 'location_name' => $loc);
        $this->db->select('*');
        $this->db->from('jobshare_resumes');
                //$this->db->like($array_name);
        $this->db->like('JobTitle', $cat);
//        $this->db->or_like('company_name', $cat);
//        $this->db->or_like('location_name', $loc);
        //$this->db->or_where('jj.job_title',$cat);
        //$this->db->or_where('jj.company_name',$cat);
        //$this->db->where('jl.location_name',$loc);
        $query = $this->db->get();
        //echo $this->db->last_query();die();
        return $query->result();
    }
    
    
     function record_count($cat) {
        //  die('dsfd');
        // $array_name = array('job_title' => $cat, 'company_name' => $cat, 'location_name' => $loc);
        $this->db->select('*');
        $this->db->from('jobshare_resumes');
        
        //$this->db->like($array_name);
        $this->db->like('JobTitle', $cat);
//        $this->db->or_like('company_name', $cat);
//        $this->db->like('location_name', $loc);
        //$this->db->or_where('jj.job_title',$cat);
        //$this->db->or_where('jj.company_name',$cat);
        //$this->db->where('jl.location_name',$loc);
        $query = $this->db->get();
        //echo $this->db->last_query();die();
        return $query->num_rows();
        
    }
    
    
    
    

}
