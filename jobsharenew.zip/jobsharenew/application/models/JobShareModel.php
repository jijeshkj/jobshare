<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class JobShareModel extends CI_Model {

    function register($data) {

        return $this->db->insert('jobshare_users', $data);
    }

    function SaveuploadResume($data) {
        return $this->db->insert('jobshare_resumes', $data);
    }

    function getExistRecord($user) {
        try {
            $this->db->where('username', $user);
            $query = $this->db->get('jobshare_users');
            return $query->result();
        } catch (Exception $ex) {
            
        }
    }

    function getHashKey($user) {
        try {
            $this->db->where('username', $user);
            $query = $this->db->get('jobshare_users');
            if ($query->num_rows() > 0) {
                return $query->result();
            } else {
                return FALSE;
            }
        } catch (Exception $ex) {
            
        }
    }

    function UpdateUserstatus($user) {
        try {
            $data = array('status' => '1');
            $this->db->where('username', $user);
            return $this->db->update('jobshare_users', $data);
        } catch (Exception $ex) {
            
        }
    }

    function jobRecords($jobId) {

        $this->db->select('jj.*,jq.quals_name,jc.category_name,jl.location_name');
        $this->db->where('jj.id', $jobId);
        $this->db->from('jobshare_jobs jj');
        $this->db->join('jobshare_jobqualification jq', 'jj.quals_id = jq.id');
        $this->db->join('jobshare_jobcategory jc', 'jj.cat_id = jc.id');
        $this->db->join('jobshare_joblocation jl', 'jj.joblloc_id = jl.id');
        $query = $this->db->get();
        return $query->result();
    }

}
