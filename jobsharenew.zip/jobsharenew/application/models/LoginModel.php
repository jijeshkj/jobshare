<?php

class LoginModel extends CI_Model {

    public function login($usrname, $password, $role) {
        $password = md5($password);
        $this->db->where('username', $usrname);
        $this->db->where('password', $password);
        $this->db->where('role', $role);
        $query = $this->db->get('jobshare_users');
        if ($query->num_rows() > 0) {
            $result = $query->result();

            $this->load->library('session');
            $this->session->set_userdata('username', $usrname);
            return $result;
        } 
    }

}
